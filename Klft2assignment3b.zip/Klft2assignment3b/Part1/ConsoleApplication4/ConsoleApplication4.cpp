#include "MyFLTK.h"
TesT *view;

int main(int argc, char **argv)
{
	view = new TesT();
	view->mainwindow->show(argc, argv);
	return Fl::run();
}