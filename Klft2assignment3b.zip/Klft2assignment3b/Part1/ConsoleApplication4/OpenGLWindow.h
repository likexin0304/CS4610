// OpenGLWindow.h will be the pre-compiled header
#ifndef OPENGLWINDOW_H
#define OPENGLWINDOW_H

#include <FL/Fl_Gl_Window.H>
#include <FL/gl.h>
#include <FL/Fl_Slider.H>

class OpenGLWindow : public Fl_Gl_Window
{
private:
	void handle();
	void draw();
	int LoadObj();
	float spin;
	int dv;
	int oldX, oldY;
	int handle(int event);


public:
	int objNum,objType;
	int normalDirect;
	int ShadeMode;
	double ar,fow,farr,nearr;
	double xTranss, yTranss,zTranss,xRotates,yRotates,zRotates;
	double vRotation,hRotation;
	OpenGLWindow(int x, int y, int w, int h, const char* l = 0);
	void setSpin(float sp);
	float vertex[10000][3];
	int face[10000][3];
	float mnormal[10000][3];
	float direct1[1000];
	float direct2[1000];
	float nnormal[1000];
	float templnm[1000];
	float vmax[3];
	float vmin[3];
	GLfloat amb_r;
	GLfloat amb_g;
	GLfloat amb_b;
	int amb_on;
	int l0_on;
	int l1_on;
	GLfloat l0_amb_r;
	GLfloat l0_amb_g;
	GLfloat l0_amb_b;
	GLfloat l0_diff_r;
	GLfloat l0_diff_g;
	GLfloat l0_diff_b;
	GLfloat l0_sp_r;
	GLfloat l0_sp_g;
	GLfloat l0_sp_b;
	GLfloat obj_amb_r;
	GLfloat obj_amb_g;
	GLfloat obj_amb_b;
	GLfloat obj_diff_r;
	GLfloat obj_diff_g;
	GLfloat obj_diff_b;
	GLfloat obj_sp_r;
	GLfloat obj_sp_g;
	GLfloat obj_sp_b;
	GLfloat obj_shine;



	void setDivision(int division);
	GLfloat ambientColor[4];
	GLfloat lightColor0[4];
	GLfloat lightPos0[4];
	GLfloat lightColor1[4];
	GLfloat lightPos1[4];
};

#endif