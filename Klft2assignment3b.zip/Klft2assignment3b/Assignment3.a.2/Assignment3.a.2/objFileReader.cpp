#include"objStruct.h"
#include <stdlib.h>
#include <GLUT/GLUT.h>
#include <cmath>
using namespace std;

void setFilePath(objStruct * obj, char * name)
{
    obj->filePath = name;
}

void loadObj(objStruct * obj)
{
    
    FILE *input;
    input = fopen(obj->filePath, "rt");
    char temp;
    int flag = 0;
    
    GLfloat min_x = 0.0;	GLfloat min_y = 0.0;	GLfloat min_z = 0.0;
    GLfloat max_x = 0.0;	GLfloat max_y = 0.0;	GLfloat max_z = 0.0;
    
    GLfloat f1, f2, f3, *verticesArray;
    GLint d1, d2, d3, *facesArray;
    
    obj->vertices.clear();
    obj->faces.clear();
    
    while (!feof(input))
    {
        fscanf(input, "%c", &temp);
        if (temp == 'v')
        {
            verticesArray = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            verticesArray[0] = f1;
            verticesArray[1] = f2;
            verticesArray[2] = f3;
            
            if (flag == 0)
            {
                min_x = f1; min_y = f2; min_z = f3;
                max_x = f1; max_y = f2; max_z = f3;
                flag += 1;
            }
            if (min_x > f1)		min_x = f1;
            if (min_y > f2)		min_y = f2;
            if (min_z > f3)		min_z = f3;
            if (max_x < f1)		max_x = f1;
            if (max_y < f2)		max_y = f2;
            if (max_z < f3)		max_z = f3;
            obj->vertices.push_back(verticesArray);
        }
        else if (temp == 'f')
        {
            facesArray = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            facesArray[0] = d1;
            facesArray[1] = d2;
            facesArray[2] = d3;
            obj->faces.push_back(facesArray);
        }
    }
    obj->min[0] = min_x; obj->min[1] = min_y; obj->min[2] = min_z;
    obj->max[0] = max_x; obj->max[1] = max_y; obj->max[2] = max_z;
    obj->center[0] = (max_x + min_x) / 2;
    obj->center[1] = (max_y + min_y) / 2;
    obj->center[2] = (max_z + min_z) / 2;
    obj->bLength[0] = max_x - min_x;
    obj->bLength[1] = max_y - min_y;
    obj->bLength[2] = max_z - min_z;
    fclose(input);
    
    computeFaceNormal(obj);
    computeVertexNormal(obj);
    
}


void computeFaceNormal(objStruct * obj)
{
    GLfloat vx = 0, vy = 0, vz = 0, ux = 0, uy = 0, uz = 0;
    GLfloat tmp, U[3], V[3];
    GLfloat * N;
    for (int i = 0; i < obj->faces.size(); i++)
    {
        N = new GLfloat[3];
        N[0] = 0.0; N[1] = 0.0; N[2] = 0.0;
        tmp = 0;
        for (int j = 0; j < 3; j++)
        {
            U[j] = obj->vertices[obj->faces[i][1] - 1][j] - obj->vertices[obj->faces[i][0] - 1][j];
            V[j] = obj->vertices[obj->faces[i][2] - 1][j] - obj->vertices[obj->faces[i][0] - 1][j];
        }
        
        N[0] = U[1] * V[2] - U[2] * V[1];
        N[1] = U[2] * V[0] - U[0] * V[2];
        N[2] = U[0] * V[1] - U[1] * V[0];
        
        tmp = sqrtf(pow(N[0], 2) + pow(N[1], 2) + pow(N[2], 2));
        N[0] = N[0] / tmp;
        N[1] = N[1] / tmp;
        N[2] = N[2] / tmp;
        obj->faceNormals.push_back(N);
    }
}

void computeVertexNormal(objStruct * obj)
{
    GLfloat * tmpNorm;
    int numFaces;
    
    
    for (int i = 0; i < obj->vertices.size(); i++)
    {
        tmpNorm = new GLfloat[3];
        tmpNorm[0] = 0.0; tmpNorm[1] = 0.0; tmpNorm[2] = 0.0;
        numFaces = 0;
        for (int j = 0; j < obj->faces.size(); j++)
        {
            for (int k = 0; k < 3; k++)
            {
                if (i == obj->faces[j][k] - 1)
                {
                    tmpNorm[0] += obj->faceNormals[j][0];
                    tmpNorm[1] += obj->faceNormals[j][1];
                    tmpNorm[2] += obj->faceNormals[j][2];
                }
            }
        }
        obj->vertexNormals.push_back(tmpNorm);
    }
}
