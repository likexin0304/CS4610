#define STB_IMAGE_IMPLEMENTATION
#include<ctime>
#include"objStruct.h"
#include"stb_image.h"



using namespace std;

const GLfloat P = 3.1416;

objStruct * models[3];
int flag = 0;

bool isLighted = true;
bool isLighted0 = true;
bool isLighted1 = true;
bool isMaterial = true;
bool isFlat = false;

GLfloat fovy = 40.0;
GLfloat aspect = 1.0;
GLfloat znear = 0.1;
GLfloat zfar = 5.0;

GLfloat AmbR = 0.2, AmbG = 0.1, AmbB = 1.0, AmbA = 1.0;
GLfloat DifR = 0.2, DifG = 0.2, DifB = 1.0, DifA = 1.0;
GLfloat SpeR = 0.2, SpeG = 1.0, SpeB = 1.0, SpeA = 1.0;

GLfloat mtlAmbR = 0.6, mtlAmbG = 0.3, mtlAmbB = 0.1, mtlAmbA = 1.0;
GLfloat mtlDifR = 1.0, mtlDifG = 0.5, mtlDifB = 0.0, mtlDifA = 1.0;
GLfloat mtlSpeR = 0.5, mtlSpeG = 1.0, mtlSpeB = 1.0, mtlSpeA = 1.0;
GLfloat shine = 100.0;
GLfloat eye[3] = { 0.0f, 0.0f, 2.5f };
GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
GLfloat center[3] = { 0.0f, 0.0f ,0.0f };

bool isPressed = false;
GLfloat rotateH = 0.0f;
GLfloat rotateV = 0.0f;
GLint oldX = 0;
GLint oldY = 0;

int w, h, n;
int res = stbi_info("/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/checker.jpg", &w, &h, &n);
unsigned char * image_data = stbi_load("/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/checker.jpg", &w, &h, &n, 4);


void myReshape(int w, int h)
{
    
    glViewport(0, 0, (GLint)w, (GLint)h);
    glutPostRedisplay();
}

void myInit()
{
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 0.0);
}

void loadTexture()
{
    static GLuint texName;
    glEnable(GL_TEXTURE_2D);
    glGenTextures(1, &texName);
    glBindTexture(GL_TEXTURE_2D, texName);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w,
                 h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    
    
    
}

void display(objStruct * models[], int index)
{
    glPushMatrix();
    glRotatef(rotateV, 1.0, 0.0, 0.0);
    glRotatef(rotateH, 0.0, 1.0, 0.0);
    glScalef(1 / models[index]->bLength[0], 1 / models[index]->bLength[1], 1 / models[index]->bLength[2]);
    glTranslatef(-models[index]->center[0], -models[index]->center[1], -models[index]->center[2]);
    glBegin(GL_TRIANGLES);
    for (int i = 0; i<models[index]->faces.size(); i++)
    {
        
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][0] - 1]);
        glTexCoord2f(0, 0);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][0] - 1]);
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][1] - 1]);
        glTexCoord2f(0, 1);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][1] - 1]);
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][2] - 1]);
        glTexCoord2f(1, 1);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][2] - 1]);
    }
    glEnd();
    glPopMatrix();
}

void setUpLight()
{
    GLfloat diffuse0[] = { 1.0, 0.0, 0.0, 1.0 };
    GLfloat ambient0[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat specular0[] = { 0.0, 0.4, 0.6, 1.0 };
    GLfloat light0_pos[] = { 2.5, 0.0, 4.0, 1.0 };
    
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_pos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient0);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse0);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular0);
    
    GLfloat diffuse1[] = { AmbR, AmbG, AmbB, AmbA };
    GLfloat ambient1[] = { DifR, DifG, DifB, DifA };
    GLfloat specular1[] = { SpeR, SpeG, SpeB, SpeA };
    GLfloat light1_pos[] = { 5.5, 4.0, 0.0, 1.0 };
    
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_pos);
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambient1);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse1);
    glLightfv(GL_LIGHT1, GL_SPECULAR, specular1);
    
    if (isLighted0)
        glEnable(GL_LIGHT0);
    else
        glDisable(GL_LIGHT0);
    if (isLighted1)
        glEnable(GL_LIGHT1);
    else
        glDisable(GL_LIGHT1);
}

void setUpMaterial()
{
    GLfloat mAmbient[] = { mtlAmbR, mtlAmbG, mtlAmbB, mtlAmbA };
    GLfloat mDiffuse[] = { mtlDifR, mtlDifG, mtlDifB, mtlDifA };
    GLfloat mSpecular[] = { mtlSpeR, mtlSpeG, mtlSpeB, mtlSpeA };
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, mAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mSpecular);
    glMaterialf(GL_FRONT, GL_SHININESS, shine);
}


void myDisplay()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_NORMALIZE);
    
    if (isFlat)
        glShadeModel(GL_FLAT);
    else
        glShadeModel(GL_SMOOTH);
    
    if (isLighted)
        glEnable(GL_LIGHTING);
    else
        glDisable(GL_LIGHTING);
    setUpLight();
    
    if (isMaterial)
        glEnable(GL_COLOR_MATERIAL);
    else
        glDisable(GL_COLOR_MATERIAL);
    setUpMaterial();
    loadTexture();
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fovy, aspect, znear, zfar);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);
    display(models, flag);
    glutSwapBuffers();
}

void myMouse(int button, int state, int x, int y)
{
    switch (button)
    {
        case GLUT_LEFT_BUTTON:
            if (state == GLUT_DOWN)
            {
                oldX = x;
                oldY = y;
                isPressed = true;
            }
            break;
        default:
            isPressed = false;
            break;
    }
}

void myRotation(int x, int y)
{
    if (isPressed == true)
    {
        GLint deltaX = oldX - x;
        GLint deltaY = oldY - y;
        rotateH += 360 * (GLfloat)deltaX / (GLfloat)600;
        rotateV += 360 * (GLfloat)deltaY / (GLfloat)600;
        oldX = x;
        oldY = y;
    }
    glutPostRedisplay();
}


void preFile()
{
    models[0] = new objStruct;
   
    setFilePath(models[0], "/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/cube.obj");
    
    
    loadObj(models[0]);
   
    loadTexture();
}


int main(int argc, char** argv)
{
    preFile();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("homework3.b");
    myInit();
    glutReshapeFunc(myReshape);
    glutDisplayFunc(myDisplay);

    glutMouseFunc(myMouse);
    glutMotionFunc(myRotation);
    glutMainLoop();
    return 0;
}
