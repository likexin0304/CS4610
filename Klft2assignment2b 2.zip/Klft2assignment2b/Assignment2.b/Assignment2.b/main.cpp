#include <stdlib.h>
#include <vector>
#include <iostream>
#include<math.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

/* initial tetrahedron */
#define WIN32

using namespace std;

vector <GLfloat*> vertices;
vector <GLint*> faces;

GLfloat colors[4][3] = { { 1.0, 1.0, 1.0 },{ 0.0, 1.0, 0.0 },
    { 0.0, 0.0, 1.0 },{ 0.0, 0.0, 0.0 } };

static GLfloat x = 0.0f;
static GLfloat z = 3.0f;
static GLfloat y = 0.0f;
static GLfloat tx = 1.0f;
static GLfloat ty = 1.0f;
static GLfloat tz = 1.0f;
static GLfloat  oldmy, oldmx;
static GLfloat deltax, deltay;



void objFileReader1()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/Klft2assignment2b/Assignment2.b/cube.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}

void objFileReader2()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/Klft2assignment2b/Assignment2.b/pig.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}
void objFileReader3()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/Klft2assignment2b/Assignment2.b/teapot.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}
void displayLine(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(deltax, 0.0, 1.0, 0.0);
    glRotatef(deltay, 1.0, 0.0, 0.0);
    glTranslatef(x, y, z);
    glScalef(tx, ty, tz);
    
    glBegin(GL_LINES);  // GL_LINE_STRIP
    glColor3fv(colors[1]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][0] - 1]);
    }
    glEnd();
    
    glPopMatrix();
    glutSwapBuffers();
}
void displayFace(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(deltax, 0.0, 1.0, 0.0);
    glRotatef(deltay, 1.0, 0.0, 0.0);
    glTranslatef(x, y, z);
    glScalef(tx, ty, tz);
    
    glBegin(GL_TRIANGLES);
    glColor3fv(colors[1]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
    }
    glEnd();
    
    glPopMatrix();
    glutSwapBuffers();
}
void displayPoint(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(deltax, 0.0, 1.0, 0.0);
    glRotatef(deltay, 1.0, 0.0, 0.0);
    glTranslatef(x, y, z);
    glScalef(tx, ty, tz);
    
    glBegin(GL_POINTS);
    glColor3fv(colors[0]);
    for (int i = 0; i<vertices.size(); i++)
    {
        glVertex3fv(vertices[i]);
    }
    glEnd();
    
    glPopMatrix();
    glutSwapBuffers();
}
void Mouse(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN)
        oldmx = x, oldmy = y;
}
void onMouseMove(int x, int y) {
    deltax += 360 * (x - oldmx) / 300;
    deltay += 360 * (y - oldmy) / 300;
    oldmx = x;
    oldmy = y;
}


void SpecialKeys(int key, int rx, int ry)
{
    if (key == GLUT_KEY_UP)
        y += 0.1f;
    
    if (key == GLUT_KEY_DOWN)
        y -= 0.1f;
    
    if (key == GLUT_KEY_LEFT)
        x -= 0.1f;
    
    if (key == GLUT_KEY_RIGHT)
        x += 0.1f;
    
    if (key == GLUT_KEY_F1)
        glRotatef(10, 1.0, 0.0, 0.0);
    
    if (key == GLUT_KEY_F2)
        glRotatef(10, 0.0, 1.0, 0.0);
    
    if (key == GLUT_KEY_F3)
        glRotatef(10, 0.0, 0.0, 1.0);
    if (key == GLUT_KEY_F4)
    {
        tx = tx * 1.1;
        ty = ty * 1.1;
        tz = tz * 1.1;
    }
    if (key == GLUT_KEY_F5){
        tx = tx / 1.1;
        ty = ty / 1.1;
        tz = tz / 1.1;
    }
    glutPostRedisplay();
    
}

void init()
{
    glEnable(GL_DEPTH_TEST);
}
void reshape1(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2.0, 2.0, -2.0, 2.0, -100.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void reshape2(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-20.0, 20.0, -40.0, 40.0, -400.0, 300.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void reshape3(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-200.0, -200.0, -100.0, -90.0, -400.0, 70.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void processKeys(unsigned char key, int m_x, int m_y)
{
    if(key == 'q'){
        init();
        objFileReader1();
        glutReshapeFunc(reshape1);
        glutDisplayFunc(displayLine);
        glutIdleFunc(displayLine);
    }
    if(key == 'w'){
        init();
        objFileReader1();
        glutReshapeFunc(reshape1);
        glutDisplayFunc(displayFace);
        glutIdleFunc(displayFace);
    }
    if(key == 'e'){
        init();
        objFileReader1();
        glutReshapeFunc(reshape1);
        glutDisplayFunc(displayPoint);
        glutIdleFunc(displayPoint);
    }
    if(key == 'r'){
        init();
        objFileReader2();
        glutReshapeFunc(reshape2);
        glutDisplayFunc(displayLine);
        glutIdleFunc(displayLine);
    }
    if(key == 't'){
        init();
        objFileReader2();
        glutReshapeFunc(reshape2);
        glutDisplayFunc(displayFace);
        glutIdleFunc(displayFace);
    }
    if(key == 'y'){
        init();
        objFileReader2();
        glutReshapeFunc(reshape2);
        glutDisplayFunc(displayPoint);
        glutIdleFunc(displayPoint);
    }
}

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowPosition(300, 100);
    glutInitWindowSize(600, 600);
    glutCreateWindow("OpenGL");
    init();
    objFileReader1();
    glutReshapeFunc(reshape1);
    glutDisplayFunc(displayLine);
    glutIdleFunc(displayLine);
    glutMouseFunc(Mouse);
    glutMotionFunc(onMouseMove);
    glutKeyboardFunc(processKeys);
    glutSpecialFunc(SpecialKeys);
    glutMainLoop();
    return 0;
}
