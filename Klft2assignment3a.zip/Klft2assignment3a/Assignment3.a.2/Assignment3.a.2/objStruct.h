#pragma once
#include <stdlib.h>
#include <GLUT/GLUT.h>
#include<stdlib.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>
#include <GLUT/glut.h>
#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

struct objStruct
{
    char * filePath;
    vector<GLfloat*> vertices;
    vector<GLint*> faces;
    vector<GLfloat*> vertexNormals;
    vector<GLfloat*> faceNormals;
    
    GLfloat min[3];
    GLfloat max[3];
    GLfloat center[3];
    GLfloat bLength[3];
};

void setFilePath(objStruct * obj, char * name);
void loadObj(objStruct * obj);
void computeFaceNormal(objStruct * obj);
void computeVertexNormal(objStruct * obj);
