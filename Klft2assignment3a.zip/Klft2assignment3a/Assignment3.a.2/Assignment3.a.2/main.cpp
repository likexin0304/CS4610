
#include<ctime>
#include"objStruct.h"

using namespace std;

const GLfloat P = 3.1416;


bool isMaterial = true;
bool isFlat = false;
bool isLighted = true;
bool isLighted0 = true;
bool isLighted1 = true;


objStruct * models[3];
int flag = 0;


GLfloat AmbR = 0.2, AmbG = 0.1, AmbB = 1.0, AmbA = 1.0;
GLfloat DifR = 0.2, DifG = 0.2, DifB = 1.0, DifA = 1.0;
GLfloat SpeR = 0.2, SpeG = 1.0, SpeB = 1.0, SpeA = 1.0;

GLfloat fovy = 40.0;
GLfloat aspect = 1.0;
GLfloat znear = 0.1;
GLfloat zfar = 5.0;

GLfloat mtlAmbR = 0.6, mtlAmbG = 0.3, mtlAmbB = 0.1, mtlAmbA = 1.0;
GLfloat mtlDifR = 1.0, mtlDifG = 0.5, mtlDifB = 0.0, mtlDifA = 1.0;
GLfloat mtlSpeR = 0.5, mtlSpeG = 1.0, mtlSpeB = 1.0, mtlSpeA = 1.0;
GLfloat shine = 100.0;
GLfloat eye[3] = { 0.0f, 0.0f, 2.5f };
GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
GLfloat center[3] = { 0.0f, 0.0f ,0.0f };

bool isPressed = false;
GLfloat rotateH = 0.0f;
GLfloat rotateV = 0.0f;
GLint oldX = 0;
GLint oldY = 0;


void myReshape(int w, int h)
{
    
    glViewport(0, 0, (GLint)w, (GLint)h);
    glutPostRedisplay();
}

void myInit()
{
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 1.0);
}


void setUpLight()
{
    GLfloat diffuse0[] = { 1.0, 0.0, 0.0, 1.0 };
    GLfloat ambient0[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat specular0[] = { 0.0, 0.4, 0.6, 1.0 };
    GLfloat light0_pos[] = { 2.5, 0.0, 4.0, 1.0 };
    
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_pos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient0);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse0);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular0);
    
    GLfloat diffuse1[] = { AmbR, AmbG, AmbB, AmbA };
    GLfloat ambient1[] = { DifR, DifG, DifB, DifA };
    GLfloat specular1[] = { SpeR, SpeG, SpeB, SpeA };
    GLfloat light1_pos[] = { 5.5, 4.0, 0.0, 1.0 };
    
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_pos);
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambient1);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse1);
    glLightfv(GL_LIGHT1, GL_SPECULAR, specular1);
    
    if (isLighted0)
        glEnable(GL_LIGHT0);
    else
        glDisable(GL_LIGHT0);
    if (isLighted1)
        glEnable(GL_LIGHT1);
    else
        glDisable(GL_LIGHT1);
}
void display(objStruct * models[], int index)
{
    glPushMatrix();
    glRotatef(rotateV, 1.0, 0.0, 0.0);
    glRotatef(rotateH, 0.0, 1.0, 0.0);
    glScalef(1 / models[index]->bLength[0], 1 / models[index]->bLength[1], 1 / models[index]->bLength[2]);
    glTranslatef(-models[index]->center[0], -models[index]->center[1], -models[index]->center[2]);
    glBegin(GL_TRIANGLES);
    for (int i = 0; i<models[index]->faces.size(); i++)
    {
        
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][0] - 1]);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][0] - 1]);
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][1] - 1]);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][1] - 1]);
        glNormal3fv(models[index]->vertexNormals[models[index]->faces[i][2] - 1]);
        glVertex3fv(models[index]->vertices[models[index]->faces[i][2] - 1]);
    }
    glEnd();
    glPopMatrix();
}

void setUpMaterial()
{
    GLfloat mAmbient[] = { mtlAmbR, mtlAmbG, mtlAmbB, mtlAmbA };
    GLfloat mDiffuse[] = { mtlDifR, mtlDifG, mtlDifB, mtlDifA };
    GLfloat mSpecular[] = { mtlSpeR, mtlSpeG, mtlSpeB, mtlSpeA };
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, mAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mSpecular);
    glMaterialf(GL_FRONT, GL_SHININESS, shine);
}


void myDisplay()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_NORMALIZE);
    
    if (isFlat)
        glShadeModel(GL_FLAT);
    else
        glShadeModel(GL_SMOOTH);
    
    if (isLighted)
        glEnable(GL_LIGHTING);
    else
        glDisable(GL_LIGHTING);
    setUpLight();
    
    if (isMaterial)
        glEnable(GL_COLOR_MATERIAL);
    else
        glDisable(GL_COLOR_MATERIAL);
    setUpMaterial();
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fovy, aspect, znear, zfar);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);
    display(models, flag);
    glutSwapBuffers();
}

void myKeyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
        case '1':
            flag++;
            flag = flag % 3;
            glutPostRedisplay();
            break;
        case '2':
            if (fovy < 120)
                fovy += 5.0;
            else
                fovy = 120.0;
            glutPostRedisplay();
            break;
        case '3':
            if (fovy > 20)
                fovy -= 5.0;
            else
                fovy = 20.0;
            glutPostRedisplay();
            break;
        case'4':
            znear += 0.3;
            glutPostRedisplay();
            break;
        case'5':
            znear -= 0.3;
            glutPostRedisplay();
            break;
        case'6':
            zfar += 0.7;
            glutPostRedisplay();
            break;
        case'7':
            zfar -= 0.7;
            glutPostRedisplay();
            break;
        case'8':
            aspect += 0.25;
            glutPostRedisplay();
            break;
        case'9':
            aspect -= 0.25;
            glutPostRedisplay();
            break;
        case'0':
            fovy = 40.0; aspect = 1; znear = 0.1; zfar = 5.0;
            AmbR = 0.2, AmbG = 0.1, AmbB = 1.0;
            DifR = 0.2, DifG = 0.2, DifB = 1.0;
            SpeR = 0.2, SpeG = 1.0, SpeB = 1.0;
            shine = 100.0;
            isLighted = true; isLighted0 = true;
            isLighted1 = true; isFlat = false;
            glutPostRedisplay();
            break;
        case'-':
            isLighted = !isLighted;
            glutPostRedisplay();
            break;
        case'=':
            isLighted1 = !isLighted1;
            glutPostRedisplay();
            break;
        case'q':
            isLighted0 = !isLighted0;
            glutPostRedisplay();
            break;
        case'w':
            srand((unsigned)time(0) * 10);
            AmbR = (GLfloat)(rand() % 100) / 255; AmbG = (GLfloat)(rand() % 256) / 255; AmbB = (GLfloat)(rand() % 256) / 255;
            DifR = (GLfloat)(rand() % 100) / 255; DifG = (GLfloat)(rand() % 256) / 255; DifB = (GLfloat)(rand() % 256) / 255;
            SpeR = (GLfloat)(rand() % 100) / 255; SpeG = (GLfloat)(rand() % 256) / 255; SpeB = (GLfloat)(rand() % 256) / 255;
            glutPostRedisplay();
            break;
        case'e':
            isMaterial = !isMaterial;
            glutPostRedisplay();
            break;
        case'r':
            srand((unsigned)time(0) * 10);
            mtlAmbR = (GLfloat)(rand() % 100) / 255; mtlAmbG = (GLfloat)(rand() % 256) / 255; mtlAmbB = (GLfloat)(rand() % 256) / 255;
            mtlDifR = (GLfloat)(rand() % 100) / 255; mtlDifG = (GLfloat)(rand() % 256) / 255; mtlDifB = (GLfloat)(rand() % 256) / 255;
            mtlSpeR = (GLfloat)(rand() % 100) / 255; mtlSpeG = (GLfloat)(rand() % 256) / 255; mtlSpeB = (GLfloat)(rand() % 256) / 255;
            glutPostRedisplay();
            break;
        case't':
            isFlat = !isFlat;
            glutPostRedisplay();
            break;
        default:
            break;
    }
}

void myRotation(int x, int y)
{
    if (isPressed == true)
    {
        GLint deltaX = oldX - x;
        GLint deltaY = oldY - y;
        rotateH += 360 * (GLfloat)deltaX / (GLfloat)600;
        rotateV += 360 * (GLfloat)deltaY / (GLfloat)600;
        oldX = x;
        oldY = y;
    }
    glutPostRedisplay();
}

void myMouse(int button, int state, int x, int y)
{
    switch (button)
    {
        case GLUT_LEFT_BUTTON:
            if (state == GLUT_DOWN)
            {
                oldX = x;
                oldY = y;
                isPressed = true;
            }
            break;
        default:
            isPressed = false;
            break;
    }
}

void preFile()
{
    models[0] = new objStruct;
    models[1] = new objStruct;
    models[2] = new objStruct;
    setFilePath(models[0], "/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/pig.obj");
    setFilePath(models[1], "/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/cube.obj");
    setFilePath(models[2], "/Users/likexin/Desktop/CS4610/Klft2assignment3a/Assignment3.a.2/teapot.obj");
    loadObj(models[0]);
    loadObj(models[1]);
    loadObj(models[2]);
}


int main(int argc, char** argv)
{
    preFile();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(700, 700);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Assignment 3.a");
    myInit();
    glutReshapeFunc(myReshape);
    glutDisplayFunc(myDisplay);
    glutKeyboardFunc(myKeyboard);
    glutMouseFunc(myMouse);
    glutMotionFunc(myRotation);
    glutMainLoop();
    return 0;
}
