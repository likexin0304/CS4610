#include "OpenGLWindow.h"
#include <gl/glut.h>
#include <FL/Fl.H>
#include <math.h>

OpenGLWindow::OpenGLWindow(int x, int y, int w, int h, const char* l)
	: Fl_Gl_Window(x, y, w, h, l)
{
	objNum=4;
	objType=3;
	normalDirect=0;
	vRotation = hRotation = 0.0f;
	xTranss=yTranss=zTranss=0;
	xRotates=yRotates=zRotates=0;
	ar=1.0;
	fow=45.0;
	farr=1000.0;
	nearr=1.0;
	amb_r=0.2;
	amb_g=0.2;
	amb_b=0.2;
	l0_diff_r=1.0;
	l0_diff_g=1.0;
	l0_diff_b=1.0;
	l0_amb_r=0.2;
	l0_amb_g=0.2;
	l0_amb_b=0.2;
	l0_sp_r=1.0;
	l0_sp_g=1.0;
	l0_sp_b=1.0;
	//obj_amb_r=1.0;
	//obj_amb_g=1.0;
	//obj_amb_b=1.0;
	obj_diff_r=0.1;
	obj_diff_g=0.1;
	obj_diff_b=0.1;
	obj_sp_r=0.33;
	obj_sp_g=0.33;
	obj_sp_b=0.33;
	obj_shine=10;

	amb_on=1;
	l0_on=1;
	l1_on=1;


}


void OpenGLWindow::draw()
{

	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH);


	glEnable(GL_DEPTH_TEST);
	if (ShadeMode==0){
		glShadeModel(GL_SMOOTH); //Enable smooth shading
	}
	else{
		glShadeModel(GL_FLAT);
	}


	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING); //Enable lighting
	if(l0_on==1){
		glEnable(GL_LIGHT0); //Enable light #0
	}else{
		glDisable(GL_LIGHT0); 
	}

	if(l1_on==1){
		glEnable(GL_LIGHT1); //Enable light #1
	}else{
		glDisable(GL_LIGHT1); 
	}

	glEnable(GL_NORMALIZE); //Automatically normalize normals





	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	int i,j;
	for(i=0;i<10000;i++){
		for(j=0;j<3;j++){
			vertex[i][j]=0;
			face[i][j]=0;
		}
	}

	LoadObj();
	//glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fow,ar,nearr,farr);
	glMatrixMode(GL_MODELVIEW);
	if ( !valid() )
	{
		glEnable(GL_DEPTH_TEST);
		//glClearColor (0.5, 0.5, 0.5, 1.0);
		//glViewport(0, 0, w(), h());
	}









	GLfloat material_ka[] = {1.0, 1.0, 1.0, 1.0};
	material_ka[0]=obj_amb_r;
	material_ka[1]=obj_amb_g;
	material_ka[2]=obj_amb_b;

	GLfloat material_kd[] = {0.10, 0.10, 0.10, 1.0};
	material_kd[0]=obj_diff_r;
	material_kd[1]=obj_diff_g;
	material_kd[2]=obj_diff_b;

	GLfloat material_ks[] = {0.33, 0.33, 0.33, 1.0};
	material_ks[0]=obj_sp_r;
	material_ks[1]=obj_sp_g;
	material_ks[2]=obj_sp_b;

	GLfloat material_ke[] = {0.0, 0.0, 0.0, 0.0};
	GLfloat material_se[] = {10.0};
	material_se[0]=obj_shine;

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  material_ka);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  material_kd);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,  material_ks);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION,  material_ke);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_se);



	GLfloat ambientColor[] = {0.2f, 0.2f, 0.2f, 1.0f}; //Color (0.2, 0.2, 0.2)
	ambientColor[0]=amb_r;
	ambientColor[1]=amb_g;
	ambientColor[2]=amb_b;
	if (amb_on==1){
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);
	}else{

		GLfloat ambientColor1[] = {0.0f, 0.0f, 0.0f, 1.0f};
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor1);
	}

	//Add positioned light
	//GLfloat lightColor0[] = {0.5f, 0.5f, 0.5f, 1.0f}; //Color (0.5, 0.5, 0.5)
	//GLfloat lightPos0[] = {4.0f, 0.0f, 8.0f, 1.0f}; //Positioned at (4, 0, 8)
	//glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor0);
	//glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);

	GLfloat light_pos[] = {50.0, -40.0, 40.0, 1.0};
	GLfloat light_ka[] = {0.2, 0.2, 0.2, 1.0};
	light_ka[0]=l0_amb_r;
	light_ka[1]=l0_amb_g;
	light_ka[2]=l0_amb_b;


	GLfloat light_kd[] = {1.0, 1.0, 1.0, 1.0};
	light_kd[0]=l0_diff_r;
	light_kd[1]=l0_diff_g;
	light_kd[2]=l0_diff_b;


	GLfloat light_ks[] = {1.0, 1.0, 1.0, 1.0};
	light_ks[0]=l0_sp_r;
	light_ks[1]=l0_sp_g;
	light_ks[2]=l0_sp_b;


	glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
	glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ka);
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_kd);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_ks);



	//Add directed light
	GLfloat lightColor1[] = {0.8f, 0.8f, 0.8f, 1.0f}; //Color (0.5, 0.2, 0.2)
	//Coming from the direction (-1, 0.5, 0.5)
	GLfloat lightPos1[] = {50.0f, -40.1f, 40.1f, 0.0f};
	glLightfv(GL_LIGHT1, GL_DIFFUSE, lightColor1);
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos1);











	//glPushMatrix();
	// MAtrixPush

	glMatrixMode(GL_MODELVIEW);
	//Add ambient light




	gluLookAt(0,0,-5,0,0,0,0,1,0);
	glColor3f(1.0f,1.0f,1.0f);
	glTranslatef(-xTranss,-yTranss,zTranss);
	glRotatef(vRotation, 1.0, 0.0, 0.0);
	glRotatef(hRotation, 0.0, 1.0, 0.0);
	glRotatef(xRotates, 1.0, 0.0, 0.0);
	glRotatef(yRotates, 0.0, 1.0, 0.0);
	glRotatef(zRotates, 0.0, 0.0, 1.0);
	if(objType==1){
		glPolygonMode( GL_FRONT_AND_BACK, GL_POINT );
	}
	else if(objType==2){
		glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
	}
	else if(objType==3){
		glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
	}

	int m=0;
	while(face[m][0]!=0){
		direct1[0]=vertex[face[m][1]-1][0]-vertex[face[m][0]-1][0];
		direct1[1]=vertex[face[m][1]-1][1]-vertex[face[m][0]-1][1];
		direct1[2]=vertex[face[m][1]-1][2]-vertex[face[m][0]-1][2];

		direct2[0]=vertex[face[m][2]-1][0]-vertex[face[m][0]-1][0];
		direct2[1]=vertex[face[m][2]-1][1]-vertex[face[m][0]-1][1];
		direct2[2]=vertex[face[m][2]-1][2]-vertex[face[m][0]-1][2];

		nnormal[0]=direct1[1]*direct2[2]-direct1[2]*direct2[1];
		nnormal[1]=direct1[2]*direct2[0]-direct1[0]*direct2[2];
		nnormal[2]=direct1[0]*direct2[1]-direct1[1]*direct2[0];

		templnm[0]=nnormal[0];
		templnm[1]=nnormal[1];
		templnm[2]=nnormal[2];

		nnormal[0]=nnormal[0]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[1]=nnormal[1]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[2]=nnormal[2]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);

		for(int k2=0;k2<3;k2++){
			for(int k1=0;k1<3;k1++)
				mnormal[face[m][k2]-1][k1]=mnormal[face[m][k2]-1][k1]+nnormal[k1];
		}

		m++;

	}
	glClearDepth(1.0);
	//glClearColor(1.0f, 1.0f, 1.0f, 0.0f);

	m=0;
	while(face[m][0]!=0){
		glBegin(GL_TRIANGLES);

		if(ShadeMode==0 ){
			for(int k1=0;k1<3;k1++)
				nnormal[k1]=mnormal[face[m][0]-1][k1];
		}
		else{
			direct1[0]=vertex[face[m][1]-1][0]-vertex[face[m][0]-1][0];
			direct1[1]=vertex[face[m][1]-1][1]-vertex[face[m][0]-1][1];
			direct1[2]=vertex[face[m][1]-1][2]-vertex[face[m][0]-1][2];

			direct2[0]=vertex[face[m][2]-1][0]-vertex[face[m][0]-1][0];
			direct2[1]=vertex[face[m][2]-1][1]-vertex[face[m][0]-1][1];
			direct2[2]=vertex[face[m][2]-1][2]-vertex[face[m][0]-1][2];

			nnormal[0]=direct1[1]*direct2[2]-direct1[2]*direct2[1];
			nnormal[1]=direct1[2]*direct2[0]-direct1[0]*direct2[2];
			nnormal[2]=direct1[0]*direct2[1]-direct1[1]*direct2[0];
		}

		templnm[0]=nnormal[0];
		templnm[1]=nnormal[1];
		templnm[2]=nnormal[2];
		nnormal[0]=nnormal[0]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[1]=nnormal[1]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[2]=nnormal[2]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);

		if (normalDirect==0){
			nnormal[0]=-nnormal[0];
			nnormal[1]=-nnormal[1];
			nnormal[2]=-nnormal[2];
		}

		glNormal3fv(nnormal);
		glVertex3fv(vertex[face[m][0]-1]);


		if(ShadeMode==0 ){
			for(int k1=0;k1<3;k1++)
				nnormal[k1]=mnormal[face[m][1]-1][k1];
		}
				else{
			direct1[0]=vertex[face[m][1]-1][0]-vertex[face[m][0]-1][0];
			direct1[1]=vertex[face[m][1]-1][1]-vertex[face[m][0]-1][1];
			direct1[2]=vertex[face[m][1]-1][2]-vertex[face[m][0]-1][2];

			direct2[0]=vertex[face[m][2]-1][0]-vertex[face[m][0]-1][0];
			direct2[1]=vertex[face[m][2]-1][1]-vertex[face[m][0]-1][1];
			direct2[2]=vertex[face[m][2]-1][2]-vertex[face[m][0]-1][2];

			nnormal[0]=direct1[1]*direct2[2]-direct1[2]*direct2[1];
			nnormal[1]=direct1[2]*direct2[0]-direct1[0]*direct2[2];
			nnormal[2]=direct1[0]*direct2[1]-direct1[1]*direct2[0];
		}

		templnm[0]=nnormal[0];
		templnm[1]=nnormal[1];
		templnm[2]=nnormal[2];
		nnormal[0]=nnormal[0]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[1]=nnormal[1]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[2]=nnormal[2]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);

		if (normalDirect==0){
			nnormal[0]=-nnormal[0];
			nnormal[1]=-nnormal[1];
			nnormal[2]=-nnormal[2];
		}

		glNormal3fv(nnormal);
		glVertex3fv(vertex[face[m][1]-1]);


		if(ShadeMode==0 ){
			for(int k1=0;k1<3;k1++)
				nnormal[k1]=mnormal[face[m][2]-1][k1];
		}else{
			direct1[0]=vertex[face[m][1]-1][0]-vertex[face[m][0]-1][0];
			direct1[1]=vertex[face[m][1]-1][1]-vertex[face[m][0]-1][1];
			direct1[2]=vertex[face[m][1]-1][2]-vertex[face[m][0]-1][2];

			direct2[0]=vertex[face[m][2]-1][0]-vertex[face[m][0]-1][0];
			direct2[1]=vertex[face[m][2]-1][1]-vertex[face[m][0]-1][1];
			direct2[2]=vertex[face[m][2]-1][2]-vertex[face[m][0]-1][2];

			nnormal[0]=direct1[1]*direct2[2]-direct1[2]*direct2[1];
			nnormal[1]=direct1[2]*direct2[0]-direct1[0]*direct2[2];
			nnormal[2]=direct1[0]*direct2[1]-direct1[1]*direct2[0];
		}


		templnm[0]=nnormal[0];
		templnm[1]=nnormal[1];
		templnm[2]=nnormal[2];
		nnormal[0]=nnormal[0]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[1]=nnormal[1]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		nnormal[2]=nnormal[2]/sqrt(templnm[0]*templnm[0]+templnm[1]*templnm[1]+templnm[2]*templnm[2]);
		if (normalDirect==0){
			nnormal[0]=-nnormal[0];
			nnormal[1]=-nnormal[1];
			nnormal[2]=-nnormal[2];
		}

		glNormal3fv(nnormal);
		glVertex3fv(vertex[face[m][2]-1]);


		m++;

		glEnd();

	}





	glFlush();
	if(objType==1){
		glPolygonMode( GL_FRONT_AND_BACK, GL_POINT );
	}
	else if(objType==2){
		glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
	}
	else if(objType==3){
		glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
	}


















	//MAtrix Pop
	//glPopMatrix();

}



int OpenGLWindow::handle(int event)
{
	switch ( event )
	{
	case FL_DRAG:
		hRotation += Fl::event_x() - oldX;
		vRotation += Fl::event_y() - oldY;
		redraw();
	case FL_PUSH:
		oldX = Fl::event_x();
		oldY = Fl::event_y();
		return 1;
	default: return Fl_Gl_Window::handle(event);
	}
}


int OpenGLWindow::LoadObj(){


	int i=0;
	int j=0;
	FILE* fp=fopen("d:\\mod\\tea.obj","r");
	if(objNum==1){
		fp=fopen("d:\\mod\\tea.obj","r");
	}
	else if(objNum==2){
		fp=fopen("d:\\mod\\pig.obj","r");
	}
	else if(objNum==3){
		fp=fopen("d:\\mod\\dog.obj","r");
	}
	else if(objNum==4){
		fp=fopen("d:\\mod\\cube.obj","r");
	}
	//      while(!(feof(fp))){
	//        read=fscanf(fp,"%c %f %f %f",&ch,&x,&y,&z);
	//        if(read==4&&ch=='v'){
	//                vertex[i][0]=x;
	//                vertex[i][1]=y;
	//                vertex[i][2]=z;
	//             i++;
	//                 a=i;//store the array number
	//        }
	//        else if(read==4 && ch=='f'){
	//           face[j][0]=x;
	//               face[j][1]=y;
	//               face[j][2]=z;
	//               j++;
	//        }
	//}

	while( 1 ){
		char lineHeader[128];
		// read the first word of the line
		int res = fscanf(fp, "%s", lineHeader);
		if (res == EOF)
			break; // EOF = End Of File. Quit the loop.

		// else : parse lineHeader

		if ( strcmp( lineHeader, "v" ) == 0 ){
			{
				fscanf(fp,"%f %f %f\n",&vertex[i][0],&vertex[i][1],&vertex[i][2]);
			}
			i++;
		}

		else if(strcmp( lineHeader, "f" ) == 0){
			{
				fscanf(fp,"%d %d %d\n",&face[j][0],&face[j][1],&face[j][2]);
			}

			j++;
			//printf("%d face: %d %d %d\n",i3,&face[i3-1][0],&face[i3-1][1],&face[i3-1][2]);
			//printf("%s \n",lineHeader);
		}
	}
	int a,b;
	a=i;  //save total number of vertex in a;
	b=j;  //save total number of faces in b;
	fclose(fp);
	float xmax,xmin,ymin,ymax,zmax,zmin;
	xmax=vertex[0][0];
	xmin=vertex[0][0];
	ymax=vertex[0][1];
	ymin=vertex[0][1];
	zmax=vertex[0][2];
	zmin=vertex[0][2];
	for(i=1;i<a;i++){
		if(xmax<vertex[i][0])
			xmax=vertex[i][0];
		if(xmin>vertex[i][0])
			xmin=vertex[i][0];
		if(ymax<vertex[i][1])
			ymax=vertex[i][1];
		if(ymin>vertex[i][1])
			ymin=vertex[i][1];
		if(zmax<vertex[i][2])
			zmax=vertex[i][2];
		if(zmin>vertex[i][2])
			zmin=vertex[i][2];
	}

	for(i=0;i<a;i++){
		vertex[i][0]=(vertex[i][0]-xmin-(xmax-xmin)/2)/(xmax-xmin)*3/2;
		vertex[i][1]=(vertex[i][1]-ymin-(ymax-ymin)/2)/(ymax-ymin)*3/2;
		vertex[i][2]=(vertex[i][2]-zmin-(zmax-zmin)/2)/(zmax-zmin)*3/2;
	}
	return 0;
}