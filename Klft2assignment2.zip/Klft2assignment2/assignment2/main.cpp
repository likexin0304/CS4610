//
//  main.cpp
//  assignment2
//
//  Created by LIKEXIN on 2/27/17.
//  Copyright © 2017 LIKEXIN. All rights reserved.
//



#include <stdlib.h>
#include <vector>
#include <iostream>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define WIN32

using namespace std;
vector <GLfloat*> vertices;
vector <GLint*> faces;


GLfloat colors[4][3] = { { 1.0, 1.0, 1.0 },{ 0.0, 1.0, 0.0 },
    { 0.0, 0.0, 1.0 },{ 0.0, 0.0, 0.0 } };


void objFileLoad1()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/assignment2/assignment2/cube.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}




void objFileLoad2()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/assignment2/assignment2/pig.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}
void objFileLoad3()
{
    
    char *file = "/Users/likexin/Desktop/CS4610/assignment2/assignment2/teapot.obj";
    FILE *input;
    char c;
    GLfloat f1, f2, f3, *arrayfloat;
    GLint d1, d2, d3, *arrayint;
    vertices.clear();
    faces.clear();
    input = fopen(file, "r");
    
    while (!feof(input)) {
        fscanf(input, "%c", &c);
        if (c == 'v') {
            arrayfloat = new GLfloat[3];
            fscanf(input, "%f %f %f", &f1, &f2, &f3);
            arrayfloat[0] = f1;
            arrayfloat[1] = f2;
            arrayfloat[2] = f3;
            vertices.push_back(arrayfloat);
        }
        else if (c == 'f') {
            arrayint = new GLint[3];
            fscanf(input, "%d %d %d", &d1, &d2, &d3);
            arrayint[0] = d1;
            arrayint[1] = d2;
            arrayint[2] = d3;
            faces.push_back(arrayint);
        }
    }
    fclose(input);
    
}

void display1()
{
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glOrtho(-5.0, 5.0, -5.0, 5.0, -5.0, 5.0);
    glViewport(0, 0, 300, 300);
    
    glBegin(GL_TRIANGLES);
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
    }
    glEnd();
    
    glViewport(300, 300, 300, 300);
    glBegin(GL_LINES);
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][0] - 1]);
    }
    glEnd();
    
    glViewport(0, 300, 300, 300);
    glBegin(GL_POINTS);
    glColor3fv(colors[0]);
    for (int i = 0; i<vertices.size(); i++)
    {
        glVertex3fv(vertices[i]);
    }
    glEnd();
    glLoadIdentity();
    glFlush();
}
void display2()
{
   
    
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glOrtho(-50.0, 50.0, -100.0, 100.0, -200.0, 200.0);
 
    
    glViewport(0, 0, 400, 400);
    
    glBegin(GL_TRIANGLES);
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
    }
    glEnd();
    
    glViewport(400, 400, 400, 400);
    glBegin(GL_LINES);  // GL_LINE_STRIP
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][0] - 1]);
    }
    glEnd();
    
    glViewport(0, 400, 400, 400);
    glBegin(GL_POINTS);
    glColor3fv(colors[0]);
    for (int i = 0; i<vertices.size(); i++)
    {
        glVertex3fv(vertices[i]);
        
    }
    glEnd();
    glLoadIdentity();
    glFlush();
}
void display3()
{
    
    
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glOrtho(-310.0, -300.0, -150.0, -140.2220, -450.0, 100.0);
   
    glViewport(0, 0, 300, 300);
    
    glBegin(GL_TRIANGLES);
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
    }
    glEnd();
    
    glViewport(300, 300, 300, 300);
    glBegin(GL_LINES);  // GL_LINE_STRIP
    glColor3fv(colors[0]);
    for (int i = 0; i<faces.size(); i++)
    {
        glVertex3fv(vertices[faces[i][0] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][1] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][2] - 1]);
        glVertex3fv(vertices[faces[i][0] - 1]);
    }
    glEnd();
    
    glViewport(0, 300, 300, 300);
    glBegin(GL_POINTS);
    glColor3fv(colors[0]);
    for (int i = 0; i<vertices.size(); i++)
    {
        glVertex3fv(vertices[i]);
        
    }
    glEnd();
    glLoadIdentity();
    glFlush();
}

void Keysword(unsigned char key,int x,int y){
    if(key == '1'){
        objFileLoad1();
        glutDisplayFunc(display1);
        glutPostRedisplay();
    }
    if(key == '2'){
        objFileLoad2();
        glutDisplayFunc(display2);
        glutPostRedisplay();
    }
    if(key == '3'){
        objFileLoad3();
        glutDisplayFunc(display3);
        glutPostRedisplay();
    }
  
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1200, 900);
    glutCreateWindow("Assignment2.a");
    objFileLoad1();
    glutDisplayFunc(display1);
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glutKeyboardFunc(Keysword);
    glutMainLoop();
    
}
